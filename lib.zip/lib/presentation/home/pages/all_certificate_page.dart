import 'package:flutter/material.dart';

import '../widget/certificate_list_card.dart';

class AllCertificatePage extends StatelessWidget {
  const AllCertificatePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: <Widget>[
          CertificateListCard(
            title: 'Blender Workshop Certificate',
            organization: 'IEDC CET',
            type: 'Workshop',
            date: '29 Jan 2024',
            imageUrl:
                'https://static.vecteezy.com/system/resources/previews/022/590/539/original/summer-party-poster-design-music-party-flyer-artwork-template-vector.jpg',
            onTap: () {
              // Handle tap
            },
          ),
          SizedBox(
            height: 24,
          ),
          CertificateListCard(
            title: 'Blender Workshop Certificate',
            organization: 'IEDC CET',
            type: 'Workshop',
            date: '29 Jan 2024',
            imageUrl:
                'https://static.vecteezy.com/system/resources/previews/022/590/539/original/summer-party-poster-design-music-party-flyer-artwork-template-vector.jpg',
            onTap: () {
              // Handle tap
            },
          ),
          SizedBox(
            height: 24,
          ),
        ],
      ),
    );
  }
}
