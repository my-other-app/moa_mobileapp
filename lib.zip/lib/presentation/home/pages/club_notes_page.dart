import 'package:flutter/material.dart';

import '../widget/note_card.dart';

class ClubNotesPage extends StatelessWidget {
  const ClubNotesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: Colors.white,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: <Widget>[
          NoteCard(
            logoUrl:
                'https://fastly.picsum.photos/id/288/536/354.jpg?hmac=0_DALLGv6guhuEVpDdbFjlA-yvbIhMjnl1YhHtfhW10',
            headerTitle: 'Tinkerhub HQ',
            headerSubtitle: '2 days ago',
            cardTitle: 'Another TinkerHub Card',
            description:
                'A longer description shows how the card automatically grows '
                'as the content increases.',
          ),
          SizedBox(
            height: 20,
          ),
          NoteCard(
            logoUrl:
                'https://fastly.picsum.photos/id/288/536/354.jpg?hmac=0_DALLGv6guhuEVpDdbFjlA-yvbIhMjnl1YhHtfhW10',
            headerTitle: 'Tinkerhub HQ',
            headerSubtitle: '2 days ago',
            cardTitle: 'Another TinkerHub Card',
            description:
                'A longer description shows how the card automatically grows '
                'as the content increases.',
          ),
          SizedBox(
            height: 20,
          ),
          NoteCard(
            logoUrl:
                'https://fastly.picsum.photos/id/288/536/354.jpg?hmac=0_DALLGv6guhuEVpDdbFjlA-yvbIhMjnl1YhHtfhW10',
            headerTitle: 'Tinkerhub HQ',
            headerSubtitle: '2 days ago',
            cardTitle: 'Another TinkerHub Card',
            description:
                'A longer description shows how the card automatically grows '
                'as the content increases.',
          ),
          SizedBox(
            height: 20,
          ),
          NoteCard(
            logoUrl:
                'https://fastly.picsum.photos/id/288/536/354.jpg?hmac=0_DALLGv6guhuEVpDdbFjlA-yvbIhMjnl1YhHtfhW10',
            headerTitle: 'Tinkerhub HQ',
            headerSubtitle: '2 days ago',
            cardTitle: 'Another TinkerHub Card',
            description:
                'A longer description shows how the card automatically grows '
                'as the content increases.',
          ),
        ],
      ),
    );
  }
}
